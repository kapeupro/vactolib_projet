-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 19 nov. 2021 à 14:48
-- Version du serveur : 10.4.21-MariaDB
-- Version de PHP : 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `vactolib`
--

-- --------------------------------------------------------

--
-- Structure de la table `vactolib_user`
--

CREATE TABLE `vactolib_user` (
  `id` int(11) NOT NULL,
  `nom` varchar(70) NOT NULL,
  `prenom` varchar(70) NOT NULL,
  `date_de_naissance` date DEFAULT NULL,
  `email` varchar(200) NOT NULL,
  `portable` int(12) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `token` varchar(250) NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `vactolib_user`
--

INSERT INTO `vactolib_user` (`id`, `nom`, `prenom`, `date_de_naissance`, `email`, `portable`, `password`, `token`, `status`, `created_at`) VALUES
(8, 'Fradin', 'Théo', '0000-00-00', 'theofradin@outlook.com', 608665145, '$2y$10$ArPZOwW4xn.eo95rIWXQnuLWEHP2kvK0glPuealsNchzE44ws9i1W', 'b04k5SO73Pcz1Nsz1OhUqhm7kYYDoQBtsFo8DvJ0JLLXgQ0W2HOSSoVfvU1b0Qo9K5zxQFMXftYXjDCUmp0bIGENwwDgoxkPCyOJ', 'user', '2021-11-19 09:33:48'),
(9, '', '', '0000-00-00', 'theofradin@outlook.fr', 0, '$2y$10$T/4R5HTjVsbWQxxNVBIwauJOIdBiL.ysZ2RJs2Jf8LsufppsvK/Nq', 'Vqaep4JCePJKMt9kAI6A2Ubdo5hWEjdWaNJK53N59T1ngvUZ6G55dji3EA0yQkoljfQG0muLUk5UdK0Z65S6IhkvTUqw0kZNDyao', 'user', '2021-11-19 10:37:00');

-- --------------------------------------------------------

--
-- Structure de la table `vactolib_user_vaccins`
--

CREATE TABLE `vactolib_user_vaccins` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `vaccin_id` int(11) NOT NULL,
  `vaccin_date` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `modified_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `vactolib_user_vaccins`
--

INSERT INTO `vactolib_user_vaccins` (`id`, `user_id`, `vaccin_id`, `vaccin_date`, `created_at`, `modified_at`) VALUES
(1, 8, 0, '0000-00-00 00:00:00', '2021-11-19 14:46:50', NULL),
(2, 8, 0, '0000-00-00 00:00:00', '2021-11-19 14:47:18', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `vactolib_vaccins`
--

CREATE TABLE `vactolib_vaccins` (
  `id` int(11) NOT NULL,
  `nom_vaccin` varchar(255) NOT NULL,
  `laboratoire` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `rappel` int(11) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `vactolib_vaccins`
--

INSERT INTO `vactolib_vaccins` (`id`, `nom_vaccin`, `laboratoire`, `description`, `rappel`, `status`) VALUES
(1, 'ACT-HIB', 'Laboratoire : Sanofi Pasteur', 'Vaccin conjugué contre Haemophilus influenzae type b - Act-HIB 10 microgrammes/0,5 mL, poudre et solvant pour solution injectable en seringue préremplie.', 0, 'publish'),
(3, 'AVAXIM 160 U', 'Laboratoire : Sanofi Pasteur', 'Vaccin contre l\'hépatite A (inactivé, adsorbé).', 0, 'publish');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `vactolib_user`
--
ALTER TABLE `vactolib_user`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `vactolib_user_vaccins`
--
ALTER TABLE `vactolib_user_vaccins`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `vactolib_vaccins`
--
ALTER TABLE `vactolib_vaccins`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `vactolib_user`
--
ALTER TABLE `vactolib_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `vactolib_user_vaccins`
--
ALTER TABLE `vactolib_user_vaccins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `vactolib_vaccins`
--
ALTER TABLE `vactolib_vaccins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
